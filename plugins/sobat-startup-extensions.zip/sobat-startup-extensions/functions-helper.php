<?php
/**
 * Functions for Sobat StartUp Extensions
 *
 * @package    Sobat StartUp Extensions
 * @author     Sobat StartUp <support@sobatstartup.com>
 * @license    2024 GNU General Public License
 */

if( ! function_exists( 'sobat_startup_extensions_get_widget_locate' ) ) {
    function sobat_startup_extensions_get_widget_locate( $name, $plugin_dir = SOBAT_STARTUP_EXTENSIONS_DIR ) {
    	$template = '';
    	
    	// Child theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_stylesheet_directory() . "/widgets/{$name}" ) ) {
    		$template = get_stylesheet_directory() . "/widgets/{$name}";
    	}

    	// Original theme
    	if ( ! $template && ! empty( $name ) && file_exists( get_template_directory() . "/widgets/{$name}" ) ) {
    		$template = get_template_directory() . "/widgets/{$name}";
    	}

    	// Plugin
    	if ( ! $template && ! empty( $name ) && file_exists( $plugin_dir . "/templates/widgets/{$name}" ) ) {
    		$template = $plugin_dir . "/templates/widgets/{$name}";
    	}

    	// Nothing found
    	if ( empty( $template ) ) {
    		throw new Exception( "Template /templates/widgets/{$name} in plugin dir {$plugin_dir} not found." );
    	}

    	return $template;
    }
}


<?php
/**
 * Widget base for Sobat StartUp Extensions
 *
 * @package    Sobat StartUp Extensions
 * @author     Team Sobat StartUp <team@sobatstartup.com>
 * @license    GNU General Public License
 * @copyright  2024 Team Sobat StartUp
 */

abstract class Sostex_Widget extends WP_Widget {
	
	public $template;
	abstract function getTemplate();

	public function display( $args, $instance ) {
		$this->getTemplate();
		extract($args);
		extract($instance);
		echo $before_widget;
			require sobat_startup_extensions_get_widget_locate( $this->template );
		echo $after_widget;
	}
}
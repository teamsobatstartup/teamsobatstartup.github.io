<?php
/**
 * Footer manager for Sobat StartUp Extensions
 *
 * @package    Sobat StartUp Extensions
 * @author     Team Sobat StartUp <team@sobatstartup.com>
 * @license    GNU General Public License
 * @copyright  2024 Team Sobat StartUp
 */
 
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

class Sostex_PostType_Custom_Post {

	/**
	 * Instance of Sostex_PostType_Custom_Post
	 *
	 * @var Sostex_PostType_Custom_Post
	 */
	private static $_instance = null;

	/**
	 * Instance of Sostex_PostType_Custom_Post
	 *
	 * @return Sostex_PostType_Custom_Post Instance of Sostex_PostType_Custom_Post
	 */
	public static function instance() {
		if ( ! isset( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}


	/**
	 * Constructor
	 */
	private function __construct() {
    	add_action( 'init', array( $this, 'register_post_type' ) );
    	add_action( 'admin_init', array( $this, 'add_role_caps' ) );

		add_action( 'add_meta_boxes', [ $this, 'register_metabox' ] );
		add_action( 'save_post', [ $this, 'save_meta' ] );

		add_filter( 'manage_sostex_custom_post_posts_columns', [ $this, 'set_shortcode_columns' ] );
		add_action( 'manage_sostex_custom_post_posts_custom_column', [ $this, 'render_shortcode_column' ], 10, 2 );


		
		add_action( 'pre_get_posts', [ $this, 'alter_query' ], 10, 1 );
		add_filter( 'query_vars', [ $this, 'custom_query_vars_filter'], 10, 1 );
		add_action( 'restrict_manage_posts', [ $this, 'admin_posts_filter_restrict_manage_posts'], 10, 1 );

		if ( is_admin() ) {
			add_action( 'manage_sostex_custom_post_posts_custom_column', [ $this, 'column_content' ], 10, 2 );
			add_filter( 'manage_sostex_custom_post_posts_columns', [ $this, 'column_headings' ] );

			add_filter( 'manage_edit-sostex_custom_post_sortable_columns', [ $this, 'set_custom_sortable_columns' ] );
		}
  	} 
	  
  	public static function register_post_type() {
	    $labels = array(
			'name'               => esc_html__( 'Blocks', 'sobat-startup-extensions' ),
			'singular_name'      => esc_html__( 'Blocks', 'sobat-startup-extensions' ),
			'menu_name'          => esc_html__( 'Blocks', 'sobat-startup-extensions' ),
			'name_admin_bar'     => esc_html__( 'Blocks', 'sobat-startup-extensions' ),
			'add_new'            => esc_html__( 'Add New Blocks', 'sobat-startup-extensions' ),
			'add_new_item'       => esc_html__( 'Add New Header, Footer or Block', 'sobat-startup-extensions' ),
			'new_item'           => esc_html__( 'New Blocks', 'sobat-startup-extensions' ),
			'edit_item'          => esc_html__( 'Edit Blocks', 'sobat-startup-extensions' ),
			'view_item'          => esc_html__( 'View Blocks', 'sobat-startup-extensions' ),
			'all_items'          => esc_html__( 'All Blocks', 'sobat-startup-extensions' ),
			'search_items'       => esc_html__( 'Search Blocks', 'sobat-startup-extensions' ),
			'parent_item_colon'  => esc_html__( 'Parent Blocks:', 'sobat-startup-extensions' ),
			'not_found'          => esc_html__( 'No Blocks found.', 'sobat-startup-extensions' ),
			'not_found_in_trash' => esc_html__( 'No Blocks found in Trash.', 'sobat-startup-extensions' ),
	    ); 

	    $type = 'sostex_custom_post';
 
	    register_post_type( $type,
	      	array(
		        'labels'            => apply_filters( 'sostex_postype_custom_post_labels' , $labels ),
		        'supports'          => array( 'title', 'editor' ),
		        'public'            => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
		        'has_archive'       => false,
				'exclude_from_search' => false,
		        'menu_icon' 		=> 'dashicons-layout',
		        'menu_position'     => 21,
				'capability_type'   => array($type, "{$type}s"),
				'map_meta_cap'      => true,	      	
			)
	    );

  	}

  	public static function add_role_caps() {
 
		 // Add the roles you'd like to administer the custom post types
		 $roles = array('administrator');

		 $type  = 'sostex_custom_post';
		 
		 // Loop through each role and assign capabilities
		 foreach($roles as $the_role) { 
		 
		    $role = get_role($the_role);
		 
			$role->add_cap( "read" );
			$role->add_cap( "read_{$type}");
			$role->add_cap( "read_private_{$type}s" );
			$role->add_cap( "edit_{$type}" );
			$role->add_cap( "edit_{$type}s" );
			$role->add_cap( "edit_others_{$type}s" );
			$role->add_cap( "edit_published_{$type}s" );
			$role->add_cap( "publish_{$type}s" );
			$role->add_cap( "delete_{$type}s" );
			$role->add_cap( "delete_others_{$type}s" );
			$role->add_cap( "delete_private_{$type}s" ); 
			$role->add_cap( "delete_published_{$type}s" );
		 
		 }
	}

	/**
	 * Adds the custom list table column content.
	 *
	 * @since 1.2.0
	 * @param array $column Name of column.
	 * @param int   $post_id Post id.
	 * @return void
	 */
	public function column_content( $column, $post_id ) {

		if ( 'sostex_display_rules' == $column ) {

			$type = get_post_meta( $post_id, 'sostex_block_type', true );


			if ( isset( $type ) ) { 
				echo '<div class="ast-advanced-headers-location-wrap" style="margin-bottom: 5px;">';
				echo '<strong>Type: '. $this->get_title_column_content($type) .'</strong>';
				echo '</div>';
			}
		}
	}

	private function get_title_column_content( $type ) {
		switch ($type) {
			case 'type_header':
				return '<a href="'. admin_url( 'edit.php?post_type=sostex_custom_post&sostex_block_type='. $type ) .'">'. esc_html__('Header', 'sobat-startup-extensions') .'</a>';
				break;

			case 'type_footer':
				return '<a href="'. admin_url( 'edit.php?post_type=sostex_custom_post&sostex_block_type='. $type ) .'">'. esc_html__('Footer', 'sobat-startup-extensions') .'</a>';
				break;

			case 'type_megamenu':
				return '<a href="'. admin_url( 'edit.php?post_type=sostex_custom_post&sostex_block_type='. $type ) .'">'. esc_html__('Megamenu', 'sobat-startup-extensions') .'</a>';
				break;

			default:
				return '<a href="'. admin_url( 'edit.php?post_type=sostex_custom_post&sostex_block_type='. $type ) .'">'. esc_html__('Custom Block', 'sobat-startup-extensions') .'</a>';
				break;
		}
	}

	/**
	 * Set shortcode column for template list.
	 *
	 * @param array $columns template list columns.
	 */
	function set_shortcode_columns( $columns ) {
		$date_column = $columns['date'];

		unset( $columns['date'] );

		$columns['shortcode'] = esc_html__( 'Shortcode', 'sobat-startup-extensions' );
		$columns['date']      = $date_column;

		return $columns;
	}

	/**
	 * Display shortcode in block list column.
	 *
	 * @param array $column block list column.
	 * @param int   $post_id post id.
	 */
	function render_shortcode_column( $column, $post_id ) {

		$slug = get_post_field( 'post_name', $post_id );
		switch ( $column ) {
			case 'shortcode':
				ob_start(); 
				?>
				<span class="sostex-shortcode-col-wrap">
					<input type="text" onfocus="this.select();" readonly="readonly" value='[sostex_block id="<?php echo esc_attr( $slug ); ?>"]' class="sostex-large-text code">
				</span>

				<?php

				ob_get_contents();
				break;
		}
	}

	function custom_query_vars_filter( $vars ) {
		$vars[] .= 'sostex_block_type';
		return $vars;
	}

	function alter_query( $query ) {

		if ( !is_admin() || 'sostex_custom_post' != $query->query['post_type'] )
			return;

		if ( !empty($query->query_vars['sostex_block_type']) ) {
			$query->set( 'meta_key', 'sostex_block_type' );
			$query->set( 'meta_value', $query->query_vars['sostex_block_type'] );
		}
	}

	function admin_posts_filter_restrict_manage_posts( $post_type ){
		if( 'sostex_custom_post' !== $post_type ){
			return;
		}
	
		$values = array(
			'Custom' => 'custom', 
			'Header' => 'type_header',
			'Footer' => 'type_footer',
			'Megamenu' => 'type_megamenu',
		);
		?>
		<select name="sostex_block_type">
		<option value=""><?php esc_html_e('Display Type ', 'sobat-startup-extensions'); ?></option>
		<?php
			$current_v = isset($_GET['sostex_block_type'])? $_GET['sostex_block_type']:'';
			foreach ($values as $label => $value) {
				printf
					(
						'<option value="%s"%s>%s</option>',
						$value,
						$value == $current_v? ' selected="selected"':'',
						$label
					);
				}
		?>
		</select>
		<?php
	}

	
	/**
	 * Adds or removes list table column headings.
	 *
	 * @param array $columns Array of columns.
	 * @return array
	 */
	public function column_headings( $columns ) {
		unset( $columns['date'] );

		$columns['sostex_display_rules'] 		= esc_html__( 'Display Type', 'sobat-startup-extensions' );
		$columns['date']                    = esc_html__( 'Date', 'sobat-startup-extensions' );

		return $columns;
	}

		/**
	 * Register meta box(es).
	 */
	function register_metabox() {
		add_meta_box(
			'sobat-startup-extensions-meta-box',
			esc_html__( 'Blocks Options', 'sobat-startup-extensions' ),
			[
				$this,
				'sostex_metabox_render',
			],
			'sostex_custom_post',
			'normal',
			'high'
		);
	}

	
	/**
	 * Render Meta field.
	 *
	 * @param  POST $post Currennt post object which is being displayed.
	 */
	public function sostex_metabox_render( $post ) {
		$values            = get_post_custom( $post->ID );
		$template_type     = isset( $values['sostex_block_type'] ) ? esc_attr( $values['sostex_block_type'][0] ) : '';

		// We'll use this nonce field later on when saving.
		wp_nonce_field( 'sostex_meta_nounce', 'sostex_meta_nounce' );

		$slug = get_post_field( 'post_name', $post->ID );
		?>
		<table class="sostex-options-table widefat">
			<tbody>
				<tr class="sostex-options-row type-of-template">
					<td class="sostex-options-row-heading">
						<label for="sostex_block_type"><?php _e( 'Type of Template', 'sobat-startup-extensions' ); ?></label>
					</td>
					<td class="sostex-options-row-content">
						<select name="sostex_block_type" id="sostex_block_type">
							<option value="custom" <?php selected( $template_type, 'custom' ); ?>><?php _e( 'Custom Block', 'sobat-startup-extensions' ); ?></option>
							<option value="type_header" <?php selected( $template_type, 'type_header' ); ?>><?php _e( 'Header', 'sobat-startup-extensions' ); ?></option>
							<option value="type_footer" <?php selected( $template_type, 'type_footer' ); ?>><?php _e( 'Footer', 'sobat-startup-extensions' ); ?></option>
							<option value="type_megamenu" <?php selected( $template_type, 'type_megamenu' ); ?>><?php _e( 'Megamenu', 'sobat-startup-extensions' ); ?></option>
						</select>
					</td>
				</tr> 

				<tr class="sostex-options-row sostex-shortcode">
					<td class="sostex-options-row-heading">
						<label for="sostex_block_type"><?php _e( 'Shortcode', 'sobat-startup-extensions' ); ?></label>
						<i class="sostex-options-row-heading-help dashicons dashicons-editor-help" title="<?php _e( 'Copy this shortcode and paste it into your post, page, or text widget content.', 'sobat-startup-extensions' ); ?>">
						</i>
					</td>
					<td class="sostex-options-row-content">
						<span class="sostex-shortcode-col-wrap">
							<input type="text" onfocus="this.select();" readonly="readonly" value='[sostex_block id="<?php echo esc_attr( $slug ); ?>"]' class="sostex-large-text code">
						</span>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Save meta field.
	 *
	 * @param  POST $post_id Currennt post object which is being displayed.
	 *
	 * @return Void
	 */
	public function save_meta( $post_id ) {

		// Bail if we're doing an auto save.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		// if our nonce isn't there, or we can't verify it, bail.
		if ( ! isset( $_POST['sostex_meta_nounce'] ) || ! wp_verify_nonce( $_POST['sostex_meta_nounce'], 'sostex_meta_nounce' ) ) {
			return;
		}

		// if our current user can't edit this post, bail.
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		if ( isset( $_POST['sostex_block_type'] ) ) {
			update_post_meta( $post_id, 'sostex_block_type', esc_attr( $_POST['sostex_block_type'] ) );
			update_post_meta( $post_id, '_wp_page_template', 'elementor_canvas' );
		}
	}

	function set_custom_sortable_columns( $columns ) {
		$columns['shortcode'] = 'shortcode'; 
		$columns['sostex_display_rules'] = 'sostex_display_rules'; 
	  
		return $columns;
	}
}

Sostex_PostType_Custom_Post::instance();
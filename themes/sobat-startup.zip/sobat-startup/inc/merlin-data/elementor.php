<?php

class Sobat_StartUp_Merlin_Elementor {

    public function import_files_demo_startup_grocery() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-grocery/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-grocery/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-grocery/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-grocery/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Grocery',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-grocery/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-grocery/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-grocery/',
            ),
        );
    }

    public function import_files_demo_startup_fashion() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-fashion/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-fashion/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-fashion/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-fashion/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Fashion',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-fashion/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-fashion/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-fashion/',
            ),
        );
    }

    public function import_files_demo_startup_gadget() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-gadget/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-gadget/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-gadget/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-gadget/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Gadget',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-gadget/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-gadget/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-gadget/',
            ),
        );
    }

    public function import_files_demo_startup_beauty() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-beauty/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-beauty/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-beauty/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-beauty/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Beauty',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-beauty/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-beauty/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-beauty/',
            ),
        );
    }

    public function import_files_demo_startup_medical() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-medical/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-medical/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-medical/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-medical/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Medical',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-medical/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-medical/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-medical/',
            ),
        );
    }

    public function import_files_demo_startup_electronic() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-electronic/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-electronic/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-electronic/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-electronic/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Electronic',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-electronic/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-electronic/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-electronic/',
            ),
        );
    }

    public function import_files_demo_startup_automotive() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-automotive/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-automotive/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-automotive/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-automotive/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Automotive',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-automotive/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-automotive/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-automotive/',
            ),
        );
    }

    public function import_files_demo_startup_furniture() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-furniture/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-furniture/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-furniture/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-furniture/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Furniture',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-furniture/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-furniture/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-furniture/',
            ),
        );
    }

    public function import_files_demo_startup_jewelry() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-jewelry/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-jewelry/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-jewelry/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-jewelry/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Jewelry',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-jewelry/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-jewelry/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-jewelry/',
            ),
        );
    }

    public function import_files_demo_startup_watch() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-watch/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-watch/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-watch/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-watch/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Watch',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-watch/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-watch/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-watch/',
            ),
        );
    }

    public function import_files_demo_startup_book() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-book/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-book/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-book/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-book/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Book',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-book/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-book/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-book/',
            ),
        );
    }

    public function import_files_demo_startup_music() {
        $rev_sliders = array(
            "https://teamsobatstartup.github.io/themes/startup-music/slider-1.zip",
            "https://teamsobatstartup.github.io/themes/startup-music/slider-banner-home-1.zip",
        );
    
        $data_url = "https://teamsobatstartup.github.io/themes/startup-music/data.xml";
        $widget_url = "https://teamsobatstartup.github.io/themes/startup-music/widgets.wie";
        
        return array(
            array(
                'import_file_name'           => 'StartUp Music',
                'home'                       => 'home',
                'import_file_url'          	 => $data_url,
                'import_widget_file_url'     => $widget_url,
                'import_redux'         => array(
                    array(
                        'file_url'   => "https://teamsobatstartup.github.io/themes/startup-music/redux_options.json",
                        'option_name' => 'sobat_startup_sostex_theme_options',
                    ),
                ),
                'rev_sliders'                => $rev_sliders,
                'import_preview_image_url'   => "https://teamsobatstartup.github.io/themes/startup-music/screenshot.jpg",
                'import_notice'              => esc_html__('After you import this demo, you will have to setup the slider separately.', 'sobat-startup'),
                'preview_url'                => 'https://sobatstartup.com/themes/startup-music/',
            ),
        );
    }

}

<?php

/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * @since Sobat StartUp 1.0
 */
define('SOBAT_STARTUP_THEME_VERSION', '1.0');

/**
 * ------------------------------------------------------------------------------------------------
 * Define constants.
 * ------------------------------------------------------------------------------------------------
 */
define('SOBAT_STARTUP_THEME_DIR', get_template_directory_uri());
define('SOBAT_STARTUP_THEMEROOT', get_template_directory());
define('SOBAT_STARTUP_IMAGES', SOBAT_STARTUP_THEME_DIR . '/inc/assets/images/core');
define('SOBAT_STARTUP_SCRIPTS', SOBAT_STARTUP_THEME_DIR . '/inc/assets/js');

define('SOBAT_STARTUP_STYLES', SOBAT_STARTUP_THEME_DIR . '/inc/assets/css');

define('SOBAT_STARTUP_INC', 'inc');
define('SOBAT_STARTUP_MERLIN', SOBAT_STARTUP_INC . '/merlin');
define('SOBAT_STARTUP_CLASSES', SOBAT_STARTUP_INC . '/classes');
define('SOBAT_STARTUP_VENDORS', SOBAT_STARTUP_INC . '/vendors');
define('SOBAT_STARTUP_CONFIG', SOBAT_STARTUP_VENDORS . '/redux-framework/config');
define('SOBAT_STARTUP_WOOCOMMERCE', SOBAT_STARTUP_VENDORS . '/woocommerce');
define('SOBAT_STARTUP_ELEMENTOR', SOBAT_STARTUP_THEMEROOT . '/inc/vendors/elementor');
define('SOBAT_STARTUP_ELEMENTOR_TEMPLATES', SOBAT_STARTUP_THEMEROOT . '/elementor_templates');
define('SOBAT_STARTUP_PAGE_TEMPLATES', SOBAT_STARTUP_THEMEROOT . '/page-templates');
define('SOBAT_STARTUP_WIDGETS', SOBAT_STARTUP_INC . '/widgets');

define('SOBAT_STARTUP_ASSETS', SOBAT_STARTUP_THEME_DIR . '/inc/assets');
define('SOBAT_STARTUP_ASSETS_IMAGES', SOBAT_STARTUP_ASSETS    . '/images');

define('SOBAT_STARTUP_MIN_JS', '');

if (! isset($content_width)) {
    $content_width = 660;
}

function sobat_startup_sostex_get_config($name, $default = '')
{
    global $sobat_startup_options;
    if (isset($sobat_startup_options[$name])) {
        return $sobat_startup_options[$name];
    }
    return $default;
}

function sobat_startup_sostex_get_global_config($name, $default = '')
{
    $options = get_option('sobat_startup_sostex_theme_options', array());
    if (isset($options[$name])) {
        return $options[$name];
    }
    return $default;
}

<?php if (! defined('SOBAT_STARTUP_THEME_DIR')) {
    exit('No direct script access allowed');
}
/**
 * Sobat StartUp woocommerce Template Hooks
 *
 * Action/filter hooks used for Sobat StartUp woocommerce functions/templates.
 *
 */


/**
 * Sobat StartUp Header Mobile Content.
 *
 * @see sobat_startup_the_button_mobile_menu()
 * @see sobat_startup_the_logo_mobile()
 */
add_action('sobat_startup_header_mobile_content', 'sobat_startup_the_button_mobile_menu', 5);
add_action('sobat_startup_header_mobile_content', 'sobat_startup_the_icon_home_page_mobile', 10);
add_action('sobat_startup_header_mobile_content', 'sobat_startup_the_logo_mobile', 15);
add_action('sobat_startup_header_mobile_content', 'sobat_startup_the_icon_mini_cart_header_mobile', 20);


/**
 * Sobat StartUp Header Mobile before content
 *
 * @see sobat_startup_the_hook_header_mobile_all_page
 */
add_action('sobat_startup_before_header_mobile', 'sobat_startup_the_hook_header_mobile_all_page', 5);

/**Page Cart**/
remove_action('woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20);

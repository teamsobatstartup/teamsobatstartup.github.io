<?php
    if( sobat_startup_checkout_optimized() ) return;
    /**
     * sobat_startup_before_topbar_mobile hook
     */
    do_action('sobat_startup_before_footer_mobile');
    $mobile_footer_slides = sobat_startup_sostex_get_config('mobile_footer_slides');
?>



<?php
    if ($mobile_footer_slides && !empty($mobile_footer_slides)) {
        ?>
            <div class="footer-device-mobile d-xl-none clearfix">
            <?php
                /**
                * sobat_startup_before_footer_mobile hook
                */
                do_action('sobat_startup_before_footer_mobile');

        /**
        * Hook: sobat_startup_footer_mobile_content.
        *
        * @hooked sobat_startup_the_custom_list_menu_icon - 10
        */

        do_action('sobat_startup_footer_mobile_content');

        /**
        * sobat_startup_after_footer_mobile hook
        */
        do_action('sobat_startup_after_footer_mobile'); ?>
            </div>
        <?php
    }
?>


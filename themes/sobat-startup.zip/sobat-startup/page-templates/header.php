<?php

if( sobat_startup_checkout_optimized() ) {
	get_template_part('page-templates/header-checkout'); 
	return;
}

$header 	= apply_filters('sobat_startup_sostex_get_header_layout', 'header_default');

$class_header = sobat_startup_header_located_on_slider();
?>

<header id="sostex-header" class="sostex_header-template site-header <?php echo esc_attr($class_header) ?>">

	<?php if ($header != 'header_default') : ?>	

		<?php sobat_startup_sostex_display_header_builder(); ?> 

	<?php else : ?>
	
	<?php get_template_part('page-templates/header-default'); ?>

	<?php endif; ?>
	<div id="nav-cover"></div>
	<div class="bg-close-canvas-menu"></div>
</header>
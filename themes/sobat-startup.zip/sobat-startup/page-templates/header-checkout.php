<header id="sostex-header" class="sostex_header-template site-header header-checkout">
	<div class="container">
		<?php
			/**
			* sobat_startup_theme_header_checkout hook
			*
			* @hooked sobat_startup_the_logo_checkout - 10
			*/
			do_action('sobat_startup_theme_header_checkout');
		?>
	</div>
</header>
'use strict';

import Helper from './builder/helper.js';
import Builder from './builder/builder.js';
//31-05-2023
document.addEventListener('woof_front_builder_start', e => woof_front_builder = new Builder(e.detail.button));

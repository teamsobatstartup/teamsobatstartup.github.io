<div class="woof-sd-ie woof-sd-ie-checkbox woof-sd-ie-checkbox___TERM_ID__ __CLASS__">
    <input type="checkbox" hidden id="__ID__"
           data-tax="__DATA_TAX__" 
           name="__SLUG__" data-term-id="__TERM_ID__" 
           value="__VALUE__" __CHECKED__ __DISABLED__
           onchange="woof_checkbox_process_data(this, this.checked)"
           hidden
           />
    <label for="__ID__"><span></span></label>
    <b class="woof-sd-ie-title" onclick="this.parentNode.querySelector('label').click();" for="__ID__">__CONTENT__ <span class="woof-sd-ie-count">__COUNT__</span> __OPENER__</b>
    <input type="hidden" value="__TERM_NAME__" data-anchor="woof_n___DATA_ANCHOR__" />
</div>